﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace loginform_045_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() == "" && textBox2.Text.Trim() == "")
            {
                MessageBox.Show("Please enter username and password");
            }
            else
            {
                if (textBox1.Text == "Pakeeza" && textBox2.Text == "22011556-045")
                {
                    MessageBox.Show("you are successfully Login");
                }
               
            }
        }

    private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ResetApplicationState();
        }

        private void ResetApplicationState()
        {
            ResetApplicationState();
        }

    }
}
